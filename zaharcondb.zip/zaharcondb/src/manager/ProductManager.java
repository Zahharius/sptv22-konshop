/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manager;

import entity.Product;
import tools.InputProtection;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author admin
 */
public class ProductManager {
    private final Scanner scanner;
    public ProductManager(Scanner scanner) {
        this.scanner = scanner;
    }
    
    public void addProduct(){
        System.out.println("----- Add product -----");
        Product product = new Product();
        System.out.print("Enter name: ");
        product.setName(scanner.nextLine());
        System.out.print("Enter price: ");
        product.setPrice(InputProtection.intInput(1,20));
        System.out.println("Added book: "+product.toString());
    }
     public void showprod(List<Product> products) {
        System.out.println("----- Products -----");
        for (int i = 0; i < products.size(); i++) {
            System.out.printf("%s. %s%nстоит %s денег%n",
                    i+1,
                    products.get(i).getName(),
                    products.get(i).getPrice()
            );
        }
    }
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zaharcondb;

import entity.Customer;
import entity.Product;
import java.util.List;
import java.util.Scanner;
import manager.CustomerManager;
import manager.ProductManager;
import tools.InputProtection;

/**
 *
 * @author admin
 */
public class App {

    private final Scanner scanner;
    private final ProductManager productManager;
    private final CustomerManager customerManager;
    private List<Product> product;
    private List<Customer> customers;
    
    
    public App() {
        this.scanner = new Scanner(System.in);
        this.productManager = new ProductManager(scanner);
        customerManager = new CustomerManager();
    };

     public void run() {  
        boolean repeat = true;
        System.out.println("------- Shop -------");
        do{
            System.out.println("List taks:");
            System.out.println("0. Exit");
            System.out.println("1. Add new Product");
            System.out.println("2. Print products");
            System.out.println("3. Add new customer");
            System.out.println("4. Print customers");
            System.out.print("Enter task number: ");
            int task = InputProtection.intInput(0,4); 
            System.out.printf("You select task %d, for exit press \"0\", to continue press \"1\": ",task);
            int toContinue = InputProtection.intInput(0,1);
            if(toContinue == 0) continue;
            switch (task) {
                case 0:
                    repeat = false;
               break;
                case 1:
                    productManager.addProduct();
                    break;
                case 2:
                    productManager.showprod(product);
                    break;
                case 3:
                    customerManager.createCustomer();
                    break;
                case 4:
                    CustomerManager.custlist(this.customers);
                    break;
                case 5:

                    break;
                case 6:

                    break;
                case 7:

                    break;
                case 8:

                    break;
                case 9:

                    break;
                default:
                    System.out.println("Select from list tasks!");
            }
            System.out.println("-----------------------");
        }while(repeat);
        System.out.println("Бай бай");
    }
    
}


package zaharius.simanius;

import entity.Customer;
import entity.Product;
import java.util.Arrays;
import java.util.Scanner;
import manager.CustomerManager;
import manager.ProductManager;
import tools.InputProtection;
import manager.SaveManager;
import java.util.List;



public class App {
    private List<Product> products;
    int history[];
    
    private final ProductManager productManager;
    private SaveManager saveManager;
    
public App(){
    productManager = new ProductManager();

    this.history = new int[0];
    this.saveManager = new SaveManager();
    this.products = saveManager.loadProd();
    

}
    
    private boolean repeat;
    public void run(){
        boolean repeat = true;
        Scanner scanner = new Scanner(System.in);
   
    do{
        System.out.println("Канселярский уголок Захара");
        System.out.println("0.Выход из программы");
        System.out.println("1.Добавить Товар");
        System.out.println("2.Список товаров");
        System.out.println("3.Добавить покупателя");
        System.out.println("4.Список покупателей");
        System.out.println("5.ПОКУПАЮ");
        System.out.println("6.Сколько денег заработано");
        System.out.println("7.Дать покупателю ЕЩЁ ДЕНЕГ");
        System.out.println("8.Рейтинг товаров");
        System.out.println("9.Рейтинг покупателей");
        System.out.println("10.Редактирование товаров");
        System.out.println("11.Редактирование покупателей");
        System.out.println("Выберите номер задачи: ");  
        int task = InputProtection.intInput(0,11); 
        System.out.printf("Вы выбрали функцию %d, чтобы выйти нажмите \"0\", чтобы продолжить нажмите \"1\": ",task);
        int toCont = InputProtection.intInput(0,1);
        if(toCont ==0 )continue;
        switch (task) {
            case 0:
                repeat = false;
                break;
            case 1:
                System.out.println("1.Добавить Товар");
                this.products.add(productManager.createProduct());
                SaveManager.saveProd(this.products);
                break;
            case 2:
                System.out.println("2.Список товаров");
                productManager.showprod(products);
                break;
                default:
                System.out.println("леее ты не то нажал");
        }
        }while(repeat);
        System.out.println("ну давай пока");
    
    } 
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package librarybase;

import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import librarybase.entity.Book;

/**
 *
 * @author admin
 */
public class App {
    private final Scanner scanner = new Scanner(System.in);
    private EntityManager em;
    
    public App(){
        EntityManagerFactory emf = Persistance.createEntityManagerFactory("LibraryBasePU");
    }
    
    public void run() {
        boolean repeat = true;
        do{
        System.out.println("Tasks");
        System.out.println("0 - exit");
        System.out.println("1 - create book");
        int task = scanner.nextInt();
        switch(task){
            case 0:
                repeat = false;
                break;
            case 1:
                Book book = new Book();
                Book.setTitle("Война и мир");
                try {
                    em.getTransaction().begin();
                    if (book.getId = null) {
                        em.persist(book); 
                    }else{
                        em.merge(book);
                    }
                    em.getTransaction().commit();
                } catch (Exception e) {
                }
                break;
        }
        
    }while(repeat);
    }
    
    
}
